#!/usr/bin/env bash
cp $MINER_DIR/$CUSTOM_MINER/config.json.template $MINER_DIR/$CUSTOM_MINER/config.json
sed -i "s|POOL_URL_HERE|$CUSTOM_URL|" $MINER_DIR/$CUSTOM_MINER/config.json
sed -i "s/WALLET_ADDRESS_HERE/$CUSTOM_TEMPLATE/" $MINER_DIR/$CUSTOM_MINER/config.json
echo $CUSTOM_USER_CONFIG > $MINER_DIR/$CUSTOM_MINER/args.txt
