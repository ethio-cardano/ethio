#!/usr/bin/env bash
args=$(cat args.txt)
./dcrptd-miner $args
