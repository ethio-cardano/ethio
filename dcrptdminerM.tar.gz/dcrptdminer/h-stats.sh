#!/usr/bin/env bash
hashes=$(curl -s localhost:9000/stats | python3 -c "import sys, json; print(json.load(sys.stdin)['hashes'])")
uptime=$(curl -s localhost:9000/stats | python3 -c "import sys, json; print(json.load(sys.stdin)['uptime'])")
khs=$(($hashes / $uptime))
stats=$(curl -s localhost:9000/stats | python3 -c "import sys, json; stats=json.load(sys.stdin); stats['hs']=[$khs]; stats['hs_units']='hs'; stats['temp']=[0]; stats['fan']=[0]; stats['ar']=[stats['accepted'], stats['rejected']]; stats.pop('accepted'); stats.pop('rejected'); stats.pop('hashes'); print(json.dumps(stats))")
echo $stats
